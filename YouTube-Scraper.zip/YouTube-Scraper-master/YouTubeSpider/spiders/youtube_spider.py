import datetime
import time
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.http import FormRequest
from scrapy.spiders import CrawlSpider
from YouTubeSpider.items import YouTubeDataModel
from YouTubeSpider.items import YoutubeItemLoader


class YoutubeSpider(CrawlSpider):

    links_out_file = open('%s.txt' % datetime.datetime.now(), 'w')
    unique_links = {} 
    name = "YoutubeSpider"
    domain = ["youtube.com", "accounts.google.com"]

    def login(self, response):

        yield FormRequest.from_response(response, formdata={
            'Email': '',
        }, callback=self.login_step2)

    def login_step2(self, response):

        yield FormRequest.from_response(response, formdata={
            'Passwd': ''
        }, callback=self.start_extracting)

    def start_extracting(self, response):

        input_file = open('input.txt', 'r')
        start_url = []

        try:
            start_url = [self.url]
        except AttributeError:
            start_url = [link for link in input_file]

        for url in start_url:
            yield scrapy.Request(url=url
                                 , meta={'dont_merge_cookies': False}
                                 , callback=self.parse
                                 )

    def start_requests(self):        
        yield scrapy.Request('https://accounts.google.com/ServiceLogin/identifier?passive=true&uilel=3&hl=en&continue=https%3A%2F%2Fwww.youtube.com%2Fsignin%3Fnext%3D%252F%26action_handle_signin%3Dtrue%26hl%3Den%26app%3Ddesktop&service=youtube&flowName=GlifWebSignIn&flowEntry=AddSession'
                             , callback=self.login)

    def parse(self, response):       
        self.parse_links(response)

        yt_item_loader = YoutubeItemLoader(YouTubeDataModel())
        yt_item_loader.add_value('url', response.url)
        yt_item_loader.add_value('title', self.get_video_title(response))
        yt_item_loader.add_value('views', self.get_video_views(response))
        yt_item_loader.add_value('likes', self.get_video_likes(response))
        yt_item_loader.add_value('dislikes', self.get_video_dislikes(response))
        yt_item_loader.add_value('channel_name'
                                 , self.get_video_channel_name(response))
        yt_item_loader.add_value('channel_subscriber_count'
                                 , self.get_subscriber_count(response))
        yt_item_loader.add_value('publish_date'
                                 , self.get_video_publishing_date(response))

        return yt_item_loader.load_item()

    def get_video_title(self, response):
        return response.css(".watch-title::text").extract_first(default='')

    def get_video_views(self, response):
        return response.css(".watch-view-count::text")\
            .extract_first(default='')

    def get_video_likes(self, response):
        return response.css(".like-button-renderer-like-button")\
            .extract_first(default='')

    def get_video_dislikes(self, response):
        return response.css(".like-button-renderer-dislike-button")\
            .extract_first(default='')

    def get_video_channel_name(self, response):
        return response.css("div.yt-user-info")\
            .extract_first(default='')

    def get_subscriber_count(self, response):
        return response.css('.yt-subscriber-count')\
            .extract_first(default='')

    def get_video_publishing_date(self, response):
        return response.css(".watch-time-text").extract_first(default='')

    def parse_links(self, response):
        urls = LinkExtractor(canonicalize=True, allow_domains=self.domain)\
            .extract_links(response)

        for link in urls:           
            if link.url in self.unique_links:
                continue
            if 'watch?v' in link.url:
                self.links_out_file.write('%s\n' % link.url)
                self.unique_links[link.url] = 1