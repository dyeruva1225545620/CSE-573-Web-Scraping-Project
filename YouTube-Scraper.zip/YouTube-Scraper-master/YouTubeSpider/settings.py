BOT_NAME = 'YouTubeSpider'

SPIDER_MODULES = ['YouTubeSpider.spiders']
NEWSPIDER_MODULE = 'YouTubeSpider.spiders'

ROBOTSTXT_OBEY = True

COOKIES_ENABLED = True
COOKIES_DEBUG = True

ITEM_PIPELINES = {
    'YouTubeSpider.pipelines.YoutubespiderPipeline': 300,
}
