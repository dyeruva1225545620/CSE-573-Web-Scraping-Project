from scrapy.contrib.exporter import CsvItemExporter

class YoutubespiderPipeline(object):

    def __init__(self):
        self.csv_exporter = CsvItemExporter(open('data-master.csv', 'wb'))
        self.csv_exporter.encoding = 'utf-8'
        self.csv_exporter.fields_to_export = ['url', 'title'
                                              , 'views', 'likes', 'dislikes'
                                              , 'channel_name', 'publish_date'
                                              , 'channel_subscriber_count']

        self.csv_exporter.start_exporting()

    def spider_closed(self, spider):
        self.csv_exporter.finish_exporting()

    def process_item(self, item, spider):
        self.csv_exporter.export_item(item)
        return item
