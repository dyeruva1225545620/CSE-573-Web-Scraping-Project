import scrapy

class WebscrapingAiInstagramScraperItem(scrapy.Item):
    pass
