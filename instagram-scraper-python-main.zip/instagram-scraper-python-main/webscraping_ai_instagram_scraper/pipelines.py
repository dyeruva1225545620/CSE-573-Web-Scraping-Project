from itemadapter import ItemAdapter

class WebscrapingAiInstagramScraperPipeline:
    def process_item(self, item, spider):
        return item
