BOT_NAME = 'webscraping_ai_instagram_scraper'

SPIDER_MODULES = ['webscraping_ai_instagram_scraper.spiders']
NEWSPIDER_MODULE = 'webscraping_ai_instagram_scraper.spiders'

ROBOTSTXT_OBEY = False

CONCURRENT_REQUESTS = 10